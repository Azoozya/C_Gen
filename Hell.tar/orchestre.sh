#!/bin/bash
for chameau in {10..50..10}
do
    xtermn -hold -e "./autossh.sh 192.168.130.$chameau songoftime.sh"
done
