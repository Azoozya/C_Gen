#!/usr/bin/expect -f
#autossh.sh
set username root
set password azerty
set address = [lindex $argv 0]
set music = [lindex $argv 1]
set repost 192.168.130.60
# set addresses [lrange $argv 0 0]
# set switchname [lrange $argv 1 1]

#La connection durera max X secondes
 set timeout 10
 spawn ssh $username@$address
 expect "yes/no" {
 	 send "yes\r"
   expect "*?assword" { send "$password\r" }
   } "*?assword" { send "$password\r" }
#Installation de Beep.
 expect "#" {send "apt-get update\r"}
 expect "#" {send "apt-get install beep\r"}
#On récupère le beeps.tar depuis notre "repo spécial"
 expect "#" {send "scp $username@$repost:/root/beeps.tar /root/beeps.tar\r"}
 expect "yes/no" {
   send "yes\r"
   expect "*?assword" { send "$password\r" }
   } "*?assword" { send "$password\r" }
#On detar et donne les droits d'execution
 expect "#" {send "tar xvf /root/beeps.tar\r"}
 expect "#" {send "rm autossh.sh orchestre.sh\r"}
 expect "#" {send "chmod +x beeps/*\r"}
#On lance une musique
 expect "#" {send "echo Chameau \r"}
 after 2000 
# expect "#" {send "cd beeps && ./[lindex $argv 1]\r" }
 send { "exit\r"}
