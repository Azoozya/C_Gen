#include "header.hh"

void test(void)
{
  //This example come from https://gmplib.org/manual/C_002b_002b-Interface-Generalx 
  mpz_class a, b, c;

  a = 1234;
  b = "-5678";
  c = a+b;
  cout << a <<" + " << b << " = " << c << "\n";
  cout << "absolute value is " << abs(c) << "\n";

}
