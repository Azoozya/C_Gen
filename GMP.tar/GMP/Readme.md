#14 Jully 2020
Ready to use Gnu Multi Precision Arithmetic Library (GMP) 

Steps for compile :

	- make pop    //for untar the lib folder
	- make

Step for clear :

	- make purge  //for delete executable created
	- make burn   //for delete lib directory created by make pop

In the Makefile , LIBFLAGS indicate lib binary files path (-I/Path) and -l for each lib linked.
During .o creation , headers files of lib are indicated , in case of "undefined reference" look here.
