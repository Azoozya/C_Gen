#include "header.hh"

int main()
{
	test();
	return 0;
}
