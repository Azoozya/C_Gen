 #include "header.hh"

int main(int argc,const char** argv)
{
	cout << "give me a bottle of rum!" << endl;
	return 0;
}
