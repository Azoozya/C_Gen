#include <iostream>
#include <string>
#include "classes.hh"

//gmpxx is the c++ interface and include gmp.h
#ifdef __cplusplus
	#include "libgmp/gmpxx.h"
#else
	#include "libgmp/gmp.h"
#endif

using std::cout;
using std::endl;
using std::cin;
using std::string;

using std::ostream; // Used in gmp lib


void test(void);
